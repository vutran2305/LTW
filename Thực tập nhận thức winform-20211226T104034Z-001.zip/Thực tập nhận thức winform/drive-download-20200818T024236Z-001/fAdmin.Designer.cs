﻿namespace QUANLYNHANSU
{
    partial class fAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnphongban = new System.Windows.Forms.TabControl();
            this.tabStaffInfor = new System.Windows.Forms.TabPage();
            this.panel14 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.panel15 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbPassId = new System.Windows.Forms.Label();
            this.txbNameID = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.dateTimePicker5 = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.dtgvStaff = new System.Windows.Forms.DataGridView();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.txbNameStaff = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.btnShowStaff = new System.Windows.Forms.Button();
            this.btnDeleteStaff = new System.Windows.Forms.Button();
            this.btnEditStaff = new System.Windows.Forms.Button();
            this.btnAddStaff = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel30 = new System.Windows.Forms.Panel();
            this.panel31 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.panel32 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.panel33 = new System.Windows.Forms.Panel();
            this.panel34 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.panel35 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.panel36 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.panel27 = new System.Windows.Forms.Panel();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.panel29 = new System.Windows.Forms.Panel();
            this.dtgvAssignment = new System.Windows.Forms.DataGridView();
            this.panel12 = new System.Windows.Forms.Panel();
            this.btnAssignment = new System.Windows.Forms.Button();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel22 = new System.Windows.Forms.Panel();
            this.panel23 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.panel24 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.panel25 = new System.Windows.Forms.Panel();
            this.panel26 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.panel28 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.panel20 = new System.Windows.Forms.Panel();
            this.dtgvPosition = new System.Windows.Forms.DataGridView();
            this.panel21 = new System.Windows.Forms.Panel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.panel19 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.panel17 = new System.Windows.Forms.Panel();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panel54 = new System.Windows.Forms.Panel();
            this.label23 = new System.Windows.Forms.Label();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.panel53 = new System.Windows.Forms.Panel();
            this.label22 = new System.Windows.Forms.Label();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.panel52 = new System.Windows.Forms.Panel();
            this.label21 = new System.Windows.Forms.Label();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.panel51 = new System.Windows.Forms.Panel();
            this.label20 = new System.Windows.Forms.Label();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.panel50 = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.panel43 = new System.Windows.Forms.Panel();
            this.panel49 = new System.Windows.Forms.Panel();
            this.label18 = new System.Windows.Forms.Label();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.panel45 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.panel46 = new System.Windows.Forms.Panel();
            this.panel47 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.panel48 = new System.Windows.Forms.Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.panel41 = new System.Windows.Forms.Panel();
            this.dtgvLevel = new System.Windows.Forms.DataGridView();
            this.panel42 = new System.Windows.Forms.Panel();
            this.panel44 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.panel37 = new System.Windows.Forms.Panel();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.button7 = new System.Windows.Forms.Button();
            this.panel40 = new System.Windows.Forms.Panel();
            this.panel38 = new System.Windows.Forms.Panel();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.panel39 = new System.Windows.Forms.Panel();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.panel65 = new System.Windows.Forms.Panel();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.button30 = new System.Windows.Forms.Button();
            this.panel93 = new System.Windows.Forms.Panel();
            this.panel67 = new System.Windows.Forms.Panel();
            this.dateTimePicker4 = new System.Windows.Forms.DateTimePicker();
            this.label30 = new System.Windows.Forms.Label();
            this.panel66 = new System.Windows.Forms.Panel();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.label29 = new System.Windows.Forms.Label();
            this.panel64 = new System.Windows.Forms.Panel();
            this.label27 = new System.Windows.Forms.Label();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.panel62 = new System.Windows.Forms.Panel();
            this.label25 = new System.Windows.Forms.Label();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.panel63 = new System.Windows.Forms.Panel();
            this.label26 = new System.Windows.Forms.Label();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.panel59 = new System.Windows.Forms.Panel();
            this.dtdvContract = new System.Windows.Forms.DataGridView();
            this.panel60 = new System.Windows.Forms.Panel();
            this.panel61 = new System.Windows.Forms.Panel();
            this.label24 = new System.Windows.Forms.Label();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.panel57 = new System.Windows.Forms.Panel();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.button19 = new System.Windows.Forms.Button();
            this.panel58 = new System.Windows.Forms.Panel();
            this.panel55 = new System.Windows.Forms.Panel();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.panel56 = new System.Windows.Forms.Panel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.bntphongban = new System.Windows.Forms.TabPage();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.panel68 = new System.Windows.Forms.Panel();
            this.txtsdtPb = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.panel72 = new System.Windows.Forms.Panel();
            this.label35 = new System.Windows.Forms.Label();
            this.txttenPb = new System.Windows.Forms.TextBox();
            this.panel73 = new System.Windows.Forms.Panel();
            this.txtMaPB = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.panel74 = new System.Windows.Forms.Panel();
            this.dtgvDepartment = new System.Windows.Forms.DataGridView();
            this.panel75 = new System.Windows.Forms.Panel();
            this.panel76 = new System.Windows.Forms.Panel();
            this.label37 = new System.Windows.Forms.Label();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.panel77 = new System.Windows.Forms.Panel();
            this.txtcantim = new System.Windows.Forms.TextBox();
            this.button20 = new System.Windows.Forms.Button();
            this.panel78 = new System.Windows.Forms.Panel();
            this.panel79 = new System.Windows.Forms.Panel();
            this.button21 = new System.Windows.Forms.Button();
            this.btndelete = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.btnthem = new System.Windows.Forms.Button();
            this.panel80 = new System.Windows.Forms.Panel();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.btnbangluong = new System.Windows.Forms.TabPage();
            this.panel91 = new System.Windows.Forms.Panel();
            this.label41 = new System.Windows.Forms.Label();
            this.txtthuclinh = new System.Windows.Forms.TextBox();
            this.panel90 = new System.Windows.Forms.Panel();
            this.label40 = new System.Windows.Forms.Label();
            this.txtluong = new System.Windows.Forms.TextBox();
            this.panel89 = new System.Windows.Forms.Panel();
            this.label39 = new System.Windows.Forms.Label();
            this.txttenv = new System.Windows.Forms.TextBox();
            this.panel88 = new System.Windows.Forms.Panel();
            this.label28 = new System.Windows.Forms.Label();
            this.txtmanv = new System.Windows.Forms.TextBox();
            this.panel92 = new System.Windows.Forms.Panel();
            this.txthesophucap = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.panel69 = new System.Windows.Forms.Panel();
            this.txthesoluong = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.panel70 = new System.Windows.Forms.Panel();
            this.txtluongcoban = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.panel71 = new System.Windows.Forms.Panel();
            this.label34 = new System.Windows.Forms.Label();
            this.txtbacluong = new System.Windows.Forms.TextBox();
            this.panel81 = new System.Windows.Forms.Panel();
            this.dtgvSalary = new System.Windows.Forms.DataGridView();
            this.panel82 = new System.Windows.Forms.Panel();
            this.panel83 = new System.Windows.Forms.Panel();
            this.label38 = new System.Windows.Forms.Label();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.panel84 = new System.Windows.Forms.Panel();
            this.txtmacantim = new System.Windows.Forms.TextBox();
            this.button25 = new System.Windows.Forms.Button();
            this.panel85 = new System.Windows.Forms.Panel();
            this.panel86 = new System.Windows.Forms.Panel();
            this.button26 = new System.Windows.Forms.Button();
            this.btnxoa = new System.Windows.Forms.Button();
            this.btnsua = new System.Windows.Forms.Button();
            this.bntthem = new System.Windows.Forms.Button();
            this.panel87 = new System.Windows.Forms.Panel();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.btnphongban.SuspendLayout();
            this.tabStaffInfor.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvStaff)).BeginInit();
            this.panel8.SuspendLayout();
            this.panel6.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel30.SuspendLayout();
            this.panel31.SuspendLayout();
            this.panel32.SuspendLayout();
            this.panel34.SuspendLayout();
            this.panel35.SuspendLayout();
            this.panel36.SuspendLayout();
            this.panel27.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvAssignment)).BeginInit();
            this.panel12.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel26.SuspendLayout();
            this.panel28.SuspendLayout();
            this.panel20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvPosition)).BeginInit();
            this.panel18.SuspendLayout();
            this.panel16.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.panel54.SuspendLayout();
            this.panel53.SuspendLayout();
            this.panel52.SuspendLayout();
            this.panel51.SuspendLayout();
            this.panel50.SuspendLayout();
            this.panel43.SuspendLayout();
            this.panel49.SuspendLayout();
            this.panel45.SuspendLayout();
            this.panel47.SuspendLayout();
            this.panel48.SuspendLayout();
            this.panel41.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvLevel)).BeginInit();
            this.panel44.SuspendLayout();
            this.panel37.SuspendLayout();
            this.panel38.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.panel65.SuspendLayout();
            this.panel67.SuspendLayout();
            this.panel66.SuspendLayout();
            this.panel64.SuspendLayout();
            this.panel62.SuspendLayout();
            this.panel63.SuspendLayout();
            this.panel59.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtdvContract)).BeginInit();
            this.panel61.SuspendLayout();
            this.panel57.SuspendLayout();
            this.panel55.SuspendLayout();
            this.bntphongban.SuspendLayout();
            this.panel68.SuspendLayout();
            this.panel72.SuspendLayout();
            this.panel73.SuspendLayout();
            this.panel74.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvDepartment)).BeginInit();
            this.panel76.SuspendLayout();
            this.panel77.SuspendLayout();
            this.panel79.SuspendLayout();
            this.btnbangluong.SuspendLayout();
            this.panel91.SuspendLayout();
            this.panel90.SuspendLayout();
            this.panel89.SuspendLayout();
            this.panel88.SuspendLayout();
            this.panel92.SuspendLayout();
            this.panel69.SuspendLayout();
            this.panel70.SuspendLayout();
            this.panel71.SuspendLayout();
            this.panel81.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvSalary)).BeginInit();
            this.panel83.SuspendLayout();
            this.panel84.SuspendLayout();
            this.panel86.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnphongban
            // 
            this.btnphongban.Controls.Add(this.tabStaffInfor);
            this.btnphongban.Controls.Add(this.tabPage2);
            this.btnphongban.Controls.Add(this.tabPage1);
            this.btnphongban.Controls.Add(this.tabPage3);
            this.btnphongban.Controls.Add(this.tabPage4);
            this.btnphongban.Controls.Add(this.bntphongban);
            this.btnphongban.Controls.Add(this.btnbangluong);
            this.btnphongban.Location = new System.Drawing.Point(3, 0);
            this.btnphongban.Name = "btnphongban";
            this.btnphongban.SelectedIndex = 0;
            this.btnphongban.Size = new System.Drawing.Size(753, 459);
            this.btnphongban.TabIndex = 0;
            // 
            // tabStaffInfor
            // 
            this.tabStaffInfor.Controls.Add(this.panel14);
            this.tabStaffInfor.Controls.Add(this.panel10);
            this.tabStaffInfor.Controls.Add(this.panel8);
            this.tabStaffInfor.Controls.Add(this.panel6);
            this.tabStaffInfor.Location = new System.Drawing.Point(4, 22);
            this.tabStaffInfor.Name = "tabStaffInfor";
            this.tabStaffInfor.Padding = new System.Windows.Forms.Padding(3);
            this.tabStaffInfor.Size = new System.Drawing.Size(745, 433);
            this.tabStaffInfor.TabIndex = 0;
            this.tabStaffInfor.Text = "Quản lý thông tin";
            this.tabStaffInfor.UseVisualStyleBackColor = true;
            // 
            // panel14
            // 
            this.panel14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel14.Controls.Add(this.panel3);
            this.panel14.Controls.Add(this.panel4);
            this.panel14.Controls.Add(this.panel15);
            this.panel14.Controls.Add(this.panel1);
            this.panel14.Controls.Add(this.panel5);
            this.panel14.Controls.Add(this.panel2);
            this.panel14.Location = new System.Drawing.Point(444, 77);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(296, 334);
            this.panel14.TabIndex = 4;
            this.panel14.Paint += new System.Windows.Forms.PaintEventHandler(this.panel14_Paint);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.textBox3);
            this.panel3.Location = new System.Drawing.Point(0, 96);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(288, 40);
            this.panel3.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(27, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Số điện thoại:";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(112, 13);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(173, 20);
            this.textBox3.TabIndex = 2;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.label1);
            this.panel4.Controls.Add(this.textBox4);
            this.panel4.Location = new System.Drawing.Point(0, 142);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(212, 40);
            this.panel4.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Giới Tính:";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(112, 13);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(85, 20);
            this.textBox4.TabIndex = 2;
            // 
            // panel15
            // 
            this.panel15.Location = new System.Drawing.Point(461, 0);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(281, 67);
            this.panel15.TabIndex = 5;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lbPassId);
            this.panel1.Controls.Add(this.txbNameID);
            this.panel1.Location = new System.Drawing.Point(0, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(212, 40);
            this.panel1.TabIndex = 0;
            // 
            // lbPassId
            // 
            this.lbPassId.AutoSize = true;
            this.lbPassId.Location = new System.Drawing.Point(27, 16);
            this.lbPassId.Name = "lbPassId";
            this.lbPassId.Size = new System.Drawing.Size(78, 13);
            this.lbPassId.TabIndex = 1;
            this.lbPassId.Text = "Mã Nhân Viên:";
            // 
            // txbNameID
            // 
            this.txbNameID.Location = new System.Drawing.Point(112, 13);
            this.txbNameID.Name = "txbNameID";
            this.txbNameID.ReadOnly = true;
            this.txbNameID.Size = new System.Drawing.Size(85, 20);
            this.txbNameID.TabIndex = 2;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.dateTimePicker5);
            this.panel5.Controls.Add(this.label4);
            this.panel5.Location = new System.Drawing.Point(0, 188);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(289, 40);
            this.panel5.TabIndex = 4;
            // 
            // dateTimePicker5
            // 
            this.dateTimePicker5.Location = new System.Drawing.Point(93, 10);
            this.dateTimePicker5.Name = "dateTimePicker5";
            this.dateTimePicker5.Size = new System.Drawing.Size(192, 20);
            this.dateTimePicker5.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(27, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Ngày sinh:";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.textBox2);
            this.panel2.Location = new System.Drawing.Point(0, 50);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(288, 40);
            this.panel2.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(27, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tên nhân viên:";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(112, 13);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(173, 20);
            this.textBox2.TabIndex = 2;
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.dtgvStaff);
            this.panel10.Controls.Add(this.panel11);
            this.panel10.Location = new System.Drawing.Point(3, 74);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(435, 340);
            this.panel10.TabIndex = 3;
            // 
            // dtgvStaff
            // 
            this.dtgvStaff.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvStaff.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dtgvStaff.Location = new System.Drawing.Point(0, 7);
            this.dtgvStaff.Name = "dtgvStaff";
            this.dtgvStaff.Size = new System.Drawing.Size(435, 333);
            this.dtgvStaff.TabIndex = 7;
            this.dtgvStaff.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvStaff_CellContentClick);
            // 
            // panel11
            // 
            this.panel11.Location = new System.Drawing.Point(461, 0);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(281, 67);
            this.panel11.TabIndex = 5;
            // 
            // panel8
            // 
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel8.Controls.Add(this.txbNameStaff);
            this.panel8.Controls.Add(this.button1);
            this.panel8.Controls.Add(this.panel9);
            this.panel8.Location = new System.Drawing.Point(443, 3);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(296, 58);
            this.panel8.TabIndex = 2;
            // 
            // txbNameStaff
            // 
            this.txbNameStaff.Location = new System.Drawing.Point(19, 19);
            this.txbNameStaff.Name = "txbNameStaff";
            this.txbNameStaff.Size = new System.Drawing.Size(177, 20);
            this.txbNameStaff.TabIndex = 13;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button1.Location = new System.Drawing.Point(202, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(87, 51);
            this.button1.TabIndex = 12;
            this.button1.Text = "TÌM KIẾM";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // panel9
            // 
            this.panel9.Location = new System.Drawing.Point(461, 0);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(281, 67);
            this.panel9.TabIndex = 5;
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel6.Controls.Add(this.btnShowStaff);
            this.panel6.Controls.Add(this.btnDeleteStaff);
            this.panel6.Controls.Add(this.btnEditStaff);
            this.panel6.Controls.Add(this.btnAddStaff);
            this.panel6.Controls.Add(this.panel7);
            this.panel6.Location = new System.Drawing.Point(3, 3);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(434, 58);
            this.panel6.TabIndex = 1;
            // 
            // btnShowStaff
            // 
            this.btnShowStaff.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnShowStaff.Location = new System.Drawing.Point(344, 3);
            this.btnShowStaff.Name = "btnShowStaff";
            this.btnShowStaff.Size = new System.Drawing.Size(87, 51);
            this.btnShowStaff.TabIndex = 11;
            this.btnShowStaff.Text = "XEM";
            this.btnShowStaff.UseVisualStyleBackColor = false;
            this.btnShowStaff.Click += new System.EventHandler(this.btnShowStaff_Click);
            // 
            // btnDeleteStaff
            // 
            this.btnDeleteStaff.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnDeleteStaff.Location = new System.Drawing.Point(117, 3);
            this.btnDeleteStaff.Name = "btnDeleteStaff";
            this.btnDeleteStaff.Size = new System.Drawing.Size(87, 51);
            this.btnDeleteStaff.TabIndex = 10;
            this.btnDeleteStaff.Text = "XÓA ";
            this.btnDeleteStaff.UseVisualStyleBackColor = false;
            // 
            // btnEditStaff
            // 
            this.btnEditStaff.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnEditStaff.Location = new System.Drawing.Point(230, 3);
            this.btnEditStaff.Name = "btnEditStaff";
            this.btnEditStaff.Size = new System.Drawing.Size(87, 51);
            this.btnEditStaff.TabIndex = 9;
            this.btnEditStaff.Text = "SỬA";
            this.btnEditStaff.UseVisualStyleBackColor = false;
            this.btnEditStaff.Click += new System.EventHandler(this.btnEditStaff_Click);
            // 
            // btnAddStaff
            // 
            this.btnAddStaff.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnAddStaff.Location = new System.Drawing.Point(3, 3);
            this.btnAddStaff.Name = "btnAddStaff";
            this.btnAddStaff.Size = new System.Drawing.Size(87, 51);
            this.btnAddStaff.TabIndex = 8;
            this.btnAddStaff.Text = "THÊM";
            this.btnAddStaff.UseVisualStyleBackColor = false;
            this.btnAddStaff.Click += new System.EventHandler(this.btnAddStaff_Click);
            // 
            // panel7
            // 
            this.panel7.Location = new System.Drawing.Point(461, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(281, 67);
            this.panel7.TabIndex = 5;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.panel13);
            this.tabPage2.Controls.Add(this.panel12);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(745, 433);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Phân công công tác";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // panel13
            // 
            this.panel13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel13.Controls.Add(this.panel30);
            this.panel13.Controls.Add(this.panel27);
            this.panel13.Controls.Add(this.dtgvAssignment);
            this.panel13.Location = new System.Drawing.Point(0, 55);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(745, 369);
            this.panel13.TabIndex = 1;
            // 
            // panel30
            // 
            this.panel30.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel30.Controls.Add(this.panel31);
            this.panel30.Controls.Add(this.panel32);
            this.panel30.Controls.Add(this.panel33);
            this.panel30.Controls.Add(this.panel34);
            this.panel30.Controls.Add(this.panel35);
            this.panel30.Controls.Add(this.panel36);
            this.panel30.Location = new System.Drawing.Point(456, 68);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(289, 288);
            this.panel30.TabIndex = 5;
            // 
            // panel31
            // 
            this.panel31.Controls.Add(this.label8);
            this.panel31.Controls.Add(this.textBox9);
            this.panel31.Location = new System.Drawing.Point(0, 96);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(288, 40);
            this.panel31.TabIndex = 2;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(27, 16);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(79, 13);
            this.label8.TabIndex = 1;
            this.label8.Text = "Tên nhân viên:";
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(112, 13);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(173, 20);
            this.textBox9.TabIndex = 2;
            // 
            // panel32
            // 
            this.panel32.Controls.Add(this.label10);
            this.panel32.Controls.Add(this.textBox11);
            this.panel32.Location = new System.Drawing.Point(0, 142);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(212, 40);
            this.panel32.TabIndex = 3;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(27, 16);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(52, 13);
            this.label10.TabIndex = 1;
            this.label10.Text = "Địa điểm:";
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(112, 13);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(85, 20);
            this.textBox11.TabIndex = 2;
            // 
            // panel33
            // 
            this.panel33.Location = new System.Drawing.Point(461, 0);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(281, 67);
            this.panel33.TabIndex = 5;
            // 
            // panel34
            // 
            this.panel34.Controls.Add(this.label11);
            this.panel34.Controls.Add(this.textBox12);
            this.panel34.Location = new System.Drawing.Point(0, 4);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(212, 40);
            this.panel34.TabIndex = 0;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(27, 16);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(79, 13);
            this.label11.TabIndex = 1;
            this.label11.Text = "Mã phân công:";
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(112, 13);
            this.textBox12.Name = "textBox12";
            this.textBox12.ReadOnly = true;
            this.textBox12.Size = new System.Drawing.Size(85, 20);
            this.textBox12.TabIndex = 2;
            // 
            // panel35
            // 
            this.panel35.Controls.Add(this.label12);
            this.panel35.Controls.Add(this.textBox13);
            this.panel35.Location = new System.Drawing.Point(0, 188);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(212, 40);
            this.panel35.TabIndex = 4;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(27, 16);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(57, 13);
            this.label12.TabIndex = 1;
            this.label12.Text = "Ngày sinh:";
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(112, 13);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(85, 20);
            this.textBox13.TabIndex = 2;
            // 
            // panel36
            // 
            this.panel36.Controls.Add(this.label13);
            this.panel36.Controls.Add(this.textBox14);
            this.panel36.Location = new System.Drawing.Point(0, 50);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(288, 40);
            this.panel36.TabIndex = 1;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(27, 16);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(75, 13);
            this.label13.TabIndex = 1;
            this.label13.Text = "Mã nhân viên:";
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(112, 13);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(173, 20);
            this.textBox14.TabIndex = 2;
            // 
            // panel27
            // 
            this.panel27.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel27.Controls.Add(this.button8);
            this.panel27.Controls.Add(this.button9);
            this.panel27.Controls.Add(this.button10);
            this.panel27.Controls.Add(this.panel29);
            this.panel27.Location = new System.Drawing.Point(456, 3);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(322, 58);
            this.panel27.TabIndex = 2;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button8.Location = new System.Drawing.Point(96, 4);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(87, 51);
            this.button8.TabIndex = 10;
            this.button8.Text = "XÓA ";
            this.button8.UseVisualStyleBackColor = false;
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button9.Location = new System.Drawing.Point(193, 4);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(87, 51);
            this.button9.TabIndex = 9;
            this.button9.Text = "SỬA";
            this.button9.UseVisualStyleBackColor = false;
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button10.Location = new System.Drawing.Point(3, 3);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(87, 51);
            this.button10.TabIndex = 8;
            this.button10.Text = "THÊM";
            this.button10.UseVisualStyleBackColor = false;
            // 
            // panel29
            // 
            this.panel29.Location = new System.Drawing.Point(461, 0);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(281, 67);
            this.panel29.TabIndex = 5;
            // 
            // dtgvAssignment
            // 
            this.dtgvAssignment.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvAssignment.Location = new System.Drawing.Point(6, 3);
            this.dtgvAssignment.Name = "dtgvAssignment";
            this.dtgvAssignment.Size = new System.Drawing.Size(444, 353);
            this.dtgvAssignment.TabIndex = 0;
            this.dtgvAssignment.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvAssignment_CellContentClick);
            // 
            // panel12
            // 
            this.panel12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel12.Controls.Add(this.btnAssignment);
            this.panel12.Controls.Add(this.dateTimePicker2);
            this.panel12.Controls.Add(this.dateTimePicker1);
            this.panel12.Location = new System.Drawing.Point(6, 3);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(733, 46);
            this.panel12.TabIndex = 0;
            // 
            // btnAssignment
            // 
            this.btnAssignment.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnAssignment.Location = new System.Drawing.Point(333, 6);
            this.btnAssignment.Name = "btnAssignment";
            this.btnAssignment.Size = new System.Drawing.Size(97, 30);
            this.btnAssignment.TabIndex = 2;
            this.btnAssignment.Text = "Thống kê";
            this.btnAssignment.UseVisualStyleBackColor = false;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(530, 9);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker2.TabIndex = 1;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(16, 9);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(223, 20);
            this.dateTimePicker1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.panel22);
            this.tabPage1.Controls.Add(this.panel20);
            this.tabPage1.Controls.Add(this.panel18);
            this.tabPage1.Controls.Add(this.panel16);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(745, 433);
            this.tabPage1.TabIndex = 2;
            this.tabPage1.Text = "Chức vụ";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // panel22
            // 
            this.panel22.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel22.Controls.Add(this.panel23);
            this.panel22.Controls.Add(this.panel24);
            this.panel22.Controls.Add(this.panel25);
            this.panel22.Controls.Add(this.panel26);
            this.panel22.Controls.Add(this.panel28);
            this.panel22.Location = new System.Drawing.Point(454, 70);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(296, 340);
            this.panel22.TabIndex = 8;
            // 
            // panel23
            // 
            this.panel23.Controls.Add(this.label5);
            this.panel23.Controls.Add(this.textBox6);
            this.panel23.Location = new System.Drawing.Point(3, 3);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(288, 40);
            this.panel23.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(27, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = "Mã chức vụ:";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(112, 13);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(173, 20);
            this.textBox6.TabIndex = 2;
            // 
            // panel24
            // 
            this.panel24.Controls.Add(this.label6);
            this.panel24.Controls.Add(this.textBox7);
            this.panel24.Location = new System.Drawing.Point(0, 142);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(212, 40);
            this.panel24.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(27, 16);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 13);
            this.label6.TabIndex = 1;
            this.label6.Text = "Tên chức vụ:";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(112, 13);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(85, 20);
            this.textBox7.TabIndex = 2;
            // 
            // panel25
            // 
            this.panel25.Location = new System.Drawing.Point(461, 0);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(281, 67);
            this.panel25.TabIndex = 5;
            // 
            // panel26
            // 
            this.panel26.Controls.Add(this.label7);
            this.panel26.Controls.Add(this.textBox8);
            this.panel26.Location = new System.Drawing.Point(0, 96);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(212, 40);
            this.panel26.TabIndex = 3;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(27, 16);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(78, 13);
            this.label7.TabIndex = 1;
            this.label7.Text = "Mã Nhân Viên:";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(112, 13);
            this.textBox8.Name = "textBox8";
            this.textBox8.ReadOnly = true;
            this.textBox8.Size = new System.Drawing.Size(85, 20);
            this.textBox8.TabIndex = 2;
            // 
            // panel28
            // 
            this.panel28.Controls.Add(this.label9);
            this.panel28.Controls.Add(this.textBox10);
            this.panel28.Location = new System.Drawing.Point(0, 50);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(288, 40);
            this.panel28.TabIndex = 2;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(27, 16);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(79, 13);
            this.label9.TabIndex = 1;
            this.label9.Text = "Tên nhân viên:";
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(112, 13);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(173, 20);
            this.textBox10.TabIndex = 2;
            // 
            // panel20
            // 
            this.panel20.Controls.Add(this.dtgvPosition);
            this.panel20.Controls.Add(this.panel21);
            this.panel20.Location = new System.Drawing.Point(6, 70);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(435, 340);
            this.panel20.TabIndex = 7;
            // 
            // dtgvPosition
            // 
            this.dtgvPosition.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvPosition.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dtgvPosition.Location = new System.Drawing.Point(0, 7);
            this.dtgvPosition.Name = "dtgvPosition";
            this.dtgvPosition.Size = new System.Drawing.Size(435, 333);
            this.dtgvPosition.TabIndex = 7;
            this.dtgvPosition.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvPosition_CellContentClick);
            // 
            // panel21
            // 
            this.panel21.Location = new System.Drawing.Point(461, 0);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(281, 67);
            this.panel21.TabIndex = 5;
            // 
            // panel18
            // 
            this.panel18.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel18.Controls.Add(this.textBox1);
            this.panel18.Controls.Add(this.button6);
            this.panel18.Controls.Add(this.panel19);
            this.panel18.Location = new System.Drawing.Point(453, 4);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(296, 58);
            this.panel18.TabIndex = 6;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(19, 19);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(177, 20);
            this.textBox1.TabIndex = 13;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button6.Location = new System.Drawing.Point(202, 3);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(87, 51);
            this.button6.TabIndex = 12;
            this.button6.Text = "TÌM KIẾM";
            this.button6.UseVisualStyleBackColor = false;
            // 
            // panel19
            // 
            this.panel19.Location = new System.Drawing.Point(461, 0);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(281, 67);
            this.panel19.TabIndex = 5;
            // 
            // panel16
            // 
            this.panel16.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel16.Controls.Add(this.button2);
            this.panel16.Controls.Add(this.button3);
            this.panel16.Controls.Add(this.button4);
            this.panel16.Controls.Add(this.button5);
            this.panel16.Controls.Add(this.panel17);
            this.panel16.Location = new System.Drawing.Point(6, 6);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(434, 58);
            this.panel16.TabIndex = 4;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button2.Location = new System.Drawing.Point(344, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(87, 51);
            this.button2.TabIndex = 11;
            this.button2.Text = "XEM";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button3.Location = new System.Drawing.Point(117, 3);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(87, 51);
            this.button3.TabIndex = 10;
            this.button3.Text = "XÓA ";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button4.Location = new System.Drawing.Point(230, 3);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(87, 51);
            this.button4.TabIndex = 9;
            this.button4.Text = "SỬA";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button5.Location = new System.Drawing.Point(3, 3);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(87, 51);
            this.button5.TabIndex = 8;
            this.button5.Text = "THÊM";
            this.button5.UseVisualStyleBackColor = false;
            // 
            // panel17
            // 
            this.panel17.Location = new System.Drawing.Point(461, 0);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(281, 67);
            this.panel17.TabIndex = 5;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.panel54);
            this.tabPage3.Controls.Add(this.panel53);
            this.tabPage3.Controls.Add(this.panel52);
            this.tabPage3.Controls.Add(this.panel51);
            this.tabPage3.Controls.Add(this.panel50);
            this.tabPage3.Controls.Add(this.panel43);
            this.tabPage3.Controls.Add(this.panel41);
            this.tabPage3.Controls.Add(this.panel37);
            this.tabPage3.Controls.Add(this.panel38);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(745, 433);
            this.tabPage3.TabIndex = 3;
            this.tabPage3.Text = "Trình độ ";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // panel54
            // 
            this.panel54.Controls.Add(this.label23);
            this.panel54.Controls.Add(this.textBox25);
            this.panel54.Location = new System.Drawing.Point(451, 279);
            this.panel54.Name = "panel54";
            this.panel54.Size = new System.Drawing.Size(212, 40);
            this.panel54.TabIndex = 15;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(27, 16);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(79, 13);
            this.label23.TabIndex = 1;
            this.label23.Text = "Chuyên ngành ";
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(112, 13);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(85, 20);
            this.textBox25.TabIndex = 2;
            // 
            // panel53
            // 
            this.panel53.Controls.Add(this.label22);
            this.panel53.Controls.Add(this.textBox24);
            this.panel53.Location = new System.Drawing.Point(451, 233);
            this.panel53.Name = "panel53";
            this.panel53.Size = new System.Drawing.Size(212, 40);
            this.panel53.TabIndex = 14;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(27, 16);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(68, 13);
            this.label22.TabIndex = 1;
            this.label22.Text = "Tên trình độ ";
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(112, 13);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(85, 20);
            this.textBox24.TabIndex = 2;
            // 
            // panel52
            // 
            this.panel52.Controls.Add(this.label21);
            this.panel52.Controls.Add(this.textBox23);
            this.panel52.Location = new System.Drawing.Point(451, 184);
            this.panel52.Name = "panel52";
            this.panel52.Size = new System.Drawing.Size(212, 40);
            this.panel52.TabIndex = 13;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(27, 16);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(64, 13);
            this.label21.TabIndex = 1;
            this.label21.Text = "Mã trình độ ";
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(112, 13);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(85, 20);
            this.textBox23.TabIndex = 2;
            // 
            // panel51
            // 
            this.panel51.Controls.Add(this.label20);
            this.panel51.Controls.Add(this.textBox22);
            this.panel51.Location = new System.Drawing.Point(451, 138);
            this.panel51.Name = "panel51";
            this.panel51.Size = new System.Drawing.Size(212, 40);
            this.panel51.TabIndex = 12;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(27, 16);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(78, 13);
            this.label20.TabIndex = 1;
            this.label20.Text = "Mã Nhân Viên:";
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(112, 13);
            this.textBox22.Name = "textBox22";
            this.textBox22.ReadOnly = true;
            this.textBox22.Size = new System.Drawing.Size(85, 20);
            this.textBox22.TabIndex = 2;
            // 
            // panel50
            // 
            this.panel50.Controls.Add(this.label19);
            this.panel50.Controls.Add(this.textBox21);
            this.panel50.Location = new System.Drawing.Point(451, 92);
            this.panel50.Name = "panel50";
            this.panel50.Size = new System.Drawing.Size(288, 40);
            this.panel50.TabIndex = 11;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(27, 16);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(79, 13);
            this.label19.TabIndex = 1;
            this.label19.Text = "Tên nhân viên:";
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(112, 13);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(173, 20);
            this.textBox21.TabIndex = 2;
            // 
            // panel43
            // 
            this.panel43.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel43.Controls.Add(this.panel49);
            this.panel43.Controls.Add(this.panel45);
            this.panel43.Controls.Add(this.panel46);
            this.panel43.Controls.Add(this.panel47);
            this.panel43.Controls.Add(this.panel48);
            this.panel43.Location = new System.Drawing.Point(1027, -93);
            this.panel43.Name = "panel43";
            this.panel43.Size = new System.Drawing.Size(296, 333);
            this.panel43.TabIndex = 9;
            // 
            // panel49
            // 
            this.panel49.Controls.Add(this.label18);
            this.panel49.Controls.Add(this.textBox20);
            this.panel49.Location = new System.Drawing.Point(3, 141);
            this.panel49.Name = "panel49";
            this.panel49.Size = new System.Drawing.Size(259, 40);
            this.panel49.TabIndex = 6;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(15, 16);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(103, 13);
            this.label18.TabIndex = 1;
            this.label18.Text = "Mã trình độ học vấn";
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(124, 13);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(85, 20);
            this.textBox20.TabIndex = 2;
            // 
            // panel45
            // 
            this.panel45.Controls.Add(this.label15);
            this.panel45.Controls.Add(this.textBox17);
            this.panel45.Location = new System.Drawing.Point(3, 95);
            this.panel45.Name = "panel45";
            this.panel45.Size = new System.Drawing.Size(212, 40);
            this.panel45.TabIndex = 3;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(16, 13);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(68, 13);
            this.label15.TabIndex = 1;
            this.label15.Text = "Tên trình độ ";
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(127, 13);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(85, 20);
            this.textBox17.TabIndex = 2;
            // 
            // panel46
            // 
            this.panel46.Location = new System.Drawing.Point(461, 0);
            this.panel46.Name = "panel46";
            this.panel46.Size = new System.Drawing.Size(281, 67);
            this.panel46.TabIndex = 5;
            // 
            // panel47
            // 
            this.panel47.Controls.Add(this.label16);
            this.panel47.Controls.Add(this.textBox18);
            this.panel47.Location = new System.Drawing.Point(3, 49);
            this.panel47.Name = "panel47";
            this.panel47.Size = new System.Drawing.Size(212, 40);
            this.panel47.TabIndex = 3;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(15, 12);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(78, 13);
            this.label16.TabIndex = 1;
            this.label16.Text = "Mã Nhân Viên:";
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(127, 9);
            this.textBox18.Name = "textBox18";
            this.textBox18.ReadOnly = true;
            this.textBox18.Size = new System.Drawing.Size(85, 20);
            this.textBox18.TabIndex = 2;
            // 
            // panel48
            // 
            this.panel48.Controls.Add(this.label17);
            this.panel48.Controls.Add(this.textBox19);
            this.panel48.Location = new System.Drawing.Point(3, 3);
            this.panel48.Name = "panel48";
            this.panel48.Size = new System.Drawing.Size(288, 40);
            this.panel48.TabIndex = 2;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(16, 13);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(79, 13);
            this.label17.TabIndex = 1;
            this.label17.Text = "Tên nhân viên:";
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(129, 13);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(139, 20);
            this.textBox19.TabIndex = 2;
            // 
            // panel41
            // 
            this.panel41.Controls.Add(this.dtgvLevel);
            this.panel41.Controls.Add(this.panel42);
            this.panel41.Controls.Add(this.panel44);
            this.panel41.Location = new System.Drawing.Point(10, 68);
            this.panel41.Name = "panel41";
            this.panel41.Size = new System.Drawing.Size(435, 340);
            this.panel41.TabIndex = 8;
            // 
            // dtgvLevel
            // 
            this.dtgvLevel.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvLevel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dtgvLevel.Location = new System.Drawing.Point(0, 7);
            this.dtgvLevel.Name = "dtgvLevel";
            this.dtgvLevel.Size = new System.Drawing.Size(435, 333);
            this.dtgvLevel.TabIndex = 7;
            this.dtgvLevel.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvLevel_CellContentClick);
            // 
            // panel42
            // 
            this.panel42.Location = new System.Drawing.Point(461, 0);
            this.panel42.Name = "panel42";
            this.panel42.Size = new System.Drawing.Size(281, 67);
            this.panel42.TabIndex = 5;
            // 
            // panel44
            // 
            this.panel44.Controls.Add(this.label14);
            this.panel44.Controls.Add(this.textBox16);
            this.panel44.Location = new System.Drawing.Point(437, 145);
            this.panel44.Name = "panel44";
            this.panel44.Size = new System.Drawing.Size(288, 40);
            this.panel44.TabIndex = 10;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(27, 16);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(67, 13);
            this.label14.TabIndex = 1;
            this.label14.Text = "Mã chức vụ:";
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(112, 13);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(173, 20);
            this.textBox16.TabIndex = 2;
            // 
            // panel37
            // 
            this.panel37.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel37.Controls.Add(this.textBox15);
            this.panel37.Controls.Add(this.button7);
            this.panel37.Controls.Add(this.panel40);
            this.panel37.Location = new System.Drawing.Point(451, 4);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(296, 58);
            this.panel37.TabIndex = 7;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(19, 19);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(177, 20);
            this.textBox15.TabIndex = 13;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button7.Location = new System.Drawing.Point(202, 3);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(87, 51);
            this.button7.TabIndex = 12;
            this.button7.Text = "TÌM KIẾM";
            this.button7.UseVisualStyleBackColor = false;
            // 
            // panel40
            // 
            this.panel40.Location = new System.Drawing.Point(461, 0);
            this.panel40.Name = "panel40";
            this.panel40.Size = new System.Drawing.Size(281, 67);
            this.panel40.TabIndex = 5;
            // 
            // panel38
            // 
            this.panel38.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel38.Controls.Add(this.button14);
            this.panel38.Controls.Add(this.button15);
            this.panel38.Controls.Add(this.button16);
            this.panel38.Controls.Add(this.button17);
            this.panel38.Controls.Add(this.panel39);
            this.panel38.Location = new System.Drawing.Point(3, 4);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(434, 58);
            this.panel38.TabIndex = 2;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button14.Location = new System.Drawing.Point(344, 3);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(87, 51);
            this.button14.TabIndex = 11;
            this.button14.Text = "XEM";
            this.button14.UseVisualStyleBackColor = false;
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button15.Location = new System.Drawing.Point(117, 3);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(87, 51);
            this.button15.TabIndex = 10;
            this.button15.Text = "XÓA ";
            this.button15.UseVisualStyleBackColor = false;
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button16.Location = new System.Drawing.Point(230, 3);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(87, 51);
            this.button16.TabIndex = 9;
            this.button16.Text = "SỬA";
            this.button16.UseVisualStyleBackColor = false;
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button17.Location = new System.Drawing.Point(3, 3);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(87, 51);
            this.button17.TabIndex = 8;
            this.button17.Text = "THÊM";
            this.button17.UseVisualStyleBackColor = false;
            // 
            // panel39
            // 
            this.panel39.Location = new System.Drawing.Point(461, 0);
            this.panel39.Name = "panel39";
            this.panel39.Size = new System.Drawing.Size(281, 67);
            this.panel39.TabIndex = 5;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.panel65);
            this.tabPage4.Controls.Add(this.panel67);
            this.tabPage4.Controls.Add(this.panel66);
            this.tabPage4.Controls.Add(this.panel64);
            this.tabPage4.Controls.Add(this.panel62);
            this.tabPage4.Controls.Add(this.panel63);
            this.tabPage4.Controls.Add(this.panel59);
            this.tabPage4.Controls.Add(this.panel57);
            this.tabPage4.Controls.Add(this.panel55);
            this.tabPage4.Controls.Add(this.menuStrip1);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(745, 433);
            this.tabPage4.TabIndex = 4;
            this.tabPage4.Text = "Phân loại hợp đồng ";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // panel65
            // 
            this.panel65.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel65.Controls.Add(this.comboBox1);
            this.panel65.Controls.Add(this.button30);
            this.panel65.Controls.Add(this.panel93);
            this.panel65.Location = new System.Drawing.Point(447, 68);
            this.panel65.Name = "panel65";
            this.panel65.Size = new System.Drawing.Size(296, 58);
            this.panel65.TabIndex = 20;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "KHÔNG XÁC ĐỊNH THỜI HẠN",
            "XÁC ĐỊNH THỜI HẠN",
            "MÙA VỤ"});
            this.comboBox1.Location = new System.Drawing.Point(22, 19);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(165, 21);
            this.comboBox1.TabIndex = 13;
            // 
            // button30
            // 
            this.button30.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button30.Location = new System.Drawing.Point(202, 3);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(87, 51);
            this.button30.TabIndex = 12;
            this.button30.Text = "PHÂN LOẠI ";
            this.button30.UseVisualStyleBackColor = false;
            // 
            // panel93
            // 
            this.panel93.Location = new System.Drawing.Point(461, 0);
            this.panel93.Name = "panel93";
            this.panel93.Size = new System.Drawing.Size(281, 67);
            this.panel93.TabIndex = 5;
            // 
            // panel67
            // 
            this.panel67.Controls.Add(this.dateTimePicker4);
            this.panel67.Controls.Add(this.label30);
            this.panel67.Location = new System.Drawing.Point(451, 322);
            this.panel67.Name = "panel67";
            this.panel67.Size = new System.Drawing.Size(288, 40);
            this.panel67.TabIndex = 18;
            // 
            // dateTimePicker4
            // 
            this.dateTimePicker4.Location = new System.Drawing.Point(125, 6);
            this.dateTimePicker4.Name = "dateTimePicker4";
            this.dateTimePicker4.Size = new System.Drawing.Size(155, 20);
            this.dateTimePicker4.TabIndex = 3;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(27, 12);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(96, 13);
            this.label30.TabIndex = 1;
            this.label30.Text = "Thời gian kết thúc ";
            // 
            // panel66
            // 
            this.panel66.Controls.Add(this.dateTimePicker3);
            this.panel66.Controls.Add(this.label29);
            this.panel66.Location = new System.Drawing.Point(451, 276);
            this.panel66.Name = "panel66";
            this.panel66.Size = new System.Drawing.Size(291, 40);
            this.panel66.TabIndex = 17;
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.Location = new System.Drawing.Point(119, 6);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(155, 20);
            this.dateTimePicker3.TabIndex = 2;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(27, 12);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(94, 13);
            this.label29.TabIndex = 1;
            this.label29.Text = "Thời gian bắt đầu ";
            // 
            // panel64
            // 
            this.panel64.Controls.Add(this.label27);
            this.panel64.Controls.Add(this.textBox30);
            this.panel64.Location = new System.Drawing.Point(451, 228);
            this.panel64.Name = "panel64";
            this.panel64.Size = new System.Drawing.Size(212, 40);
            this.panel64.TabIndex = 15;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(27, 16);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(74, 13);
            this.label27.TabIndex = 1;
            this.label27.Text = "Mã hợp đồng ";
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(119, 13);
            this.textBox30.Name = "textBox30";
            this.textBox30.ReadOnly = true;
            this.textBox30.Size = new System.Drawing.Size(85, 20);
            this.textBox30.TabIndex = 2;
            // 
            // panel62
            // 
            this.panel62.Controls.Add(this.label25);
            this.panel62.Controls.Add(this.textBox28);
            this.panel62.Location = new System.Drawing.Point(451, 182);
            this.panel62.Name = "panel62";
            this.panel62.Size = new System.Drawing.Size(212, 40);
            this.panel62.TabIndex = 14;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(27, 16);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(78, 13);
            this.label25.TabIndex = 1;
            this.label25.Text = "Mã Nhân Viên:";
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(119, 13);
            this.textBox28.Name = "textBox28";
            this.textBox28.ReadOnly = true;
            this.textBox28.Size = new System.Drawing.Size(85, 20);
            this.textBox28.TabIndex = 2;
            // 
            // panel63
            // 
            this.panel63.Controls.Add(this.label26);
            this.panel63.Controls.Add(this.textBox29);
            this.panel63.Location = new System.Drawing.Point(451, 132);
            this.panel63.Name = "panel63";
            this.panel63.Size = new System.Drawing.Size(288, 40);
            this.panel63.TabIndex = 13;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(27, 16);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(79, 13);
            this.label26.TabIndex = 1;
            this.label26.Text = "Tên nhân viên:";
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(119, 13);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(142, 20);
            this.textBox29.TabIndex = 2;
            // 
            // panel59
            // 
            this.panel59.Controls.Add(this.dtdvContract);
            this.panel59.Controls.Add(this.panel60);
            this.panel59.Controls.Add(this.panel61);
            this.panel59.Location = new System.Drawing.Point(6, 70);
            this.panel59.Name = "panel59";
            this.panel59.Size = new System.Drawing.Size(435, 340);
            this.panel59.TabIndex = 9;
            // 
            // dtdvContract
            // 
            this.dtdvContract.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtdvContract.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dtdvContract.Location = new System.Drawing.Point(0, 7);
            this.dtdvContract.Name = "dtdvContract";
            this.dtdvContract.Size = new System.Drawing.Size(435, 333);
            this.dtdvContract.TabIndex = 7;
            this.dtdvContract.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtdvContract_CellContentClick);
            // 
            // panel60
            // 
            this.panel60.Location = new System.Drawing.Point(461, 0);
            this.panel60.Name = "panel60";
            this.panel60.Size = new System.Drawing.Size(281, 67);
            this.panel60.TabIndex = 5;
            // 
            // panel61
            // 
            this.panel61.Controls.Add(this.label24);
            this.panel61.Controls.Add(this.textBox27);
            this.panel61.Location = new System.Drawing.Point(437, 145);
            this.panel61.Name = "panel61";
            this.panel61.Size = new System.Drawing.Size(288, 40);
            this.panel61.TabIndex = 10;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(27, 16);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(67, 13);
            this.label24.TabIndex = 1;
            this.label24.Text = "Mã chức vụ:";
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(112, 13);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(173, 20);
            this.textBox27.TabIndex = 2;
            // 
            // panel57
            // 
            this.panel57.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel57.Controls.Add(this.textBox26);
            this.panel57.Controls.Add(this.button19);
            this.panel57.Controls.Add(this.panel58);
            this.panel57.Location = new System.Drawing.Point(448, 6);
            this.panel57.Name = "panel57";
            this.panel57.Size = new System.Drawing.Size(296, 58);
            this.panel57.TabIndex = 8;
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(19, 19);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(177, 20);
            this.textBox26.TabIndex = 13;
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button19.Location = new System.Drawing.Point(202, 3);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(87, 51);
            this.button19.TabIndex = 12;
            this.button19.Text = "TÌM KIẾM";
            this.button19.UseVisualStyleBackColor = false;
            // 
            // panel58
            // 
            this.panel58.Location = new System.Drawing.Point(461, 0);
            this.panel58.Name = "panel58";
            this.panel58.Size = new System.Drawing.Size(281, 67);
            this.panel58.TabIndex = 5;
            // 
            // panel55
            // 
            this.panel55.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel55.Controls.Add(this.button11);
            this.panel55.Controls.Add(this.button12);
            this.panel55.Controls.Add(this.button13);
            this.panel55.Controls.Add(this.button18);
            this.panel55.Controls.Add(this.panel56);
            this.panel55.Location = new System.Drawing.Point(0, 6);
            this.panel55.Name = "panel55";
            this.panel55.Size = new System.Drawing.Size(434, 58);
            this.panel55.TabIndex = 3;
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button11.Location = new System.Drawing.Point(344, 3);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(87, 51);
            this.button11.TabIndex = 11;
            this.button11.Text = "XEM";
            this.button11.UseVisualStyleBackColor = false;
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button12.Location = new System.Drawing.Point(117, 3);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(87, 51);
            this.button12.TabIndex = 10;
            this.button12.Text = "XÓA ";
            this.button12.UseVisualStyleBackColor = false;
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button13.Location = new System.Drawing.Point(230, 3);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(87, 51);
            this.button13.TabIndex = 9;
            this.button13.Text = "SỬA";
            this.button13.UseVisualStyleBackColor = false;
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button18.Location = new System.Drawing.Point(3, 3);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(87, 51);
            this.button18.TabIndex = 8;
            this.button18.Text = "THÊM";
            this.button18.UseVisualStyleBackColor = false;
            // 
            // panel56
            // 
            this.panel56.Location = new System.Drawing.Point(461, 0);
            this.panel56.Name = "panel56";
            this.panel56.Size = new System.Drawing.Size(281, 67);
            this.panel56.TabIndex = 5;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Location = new System.Drawing.Point(3, 3);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(739, 24);
            this.menuStrip1.TabIndex = 19;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // bntphongban
            // 
            this.bntphongban.Controls.Add(this.comboBox2);
            this.bntphongban.Controls.Add(this.panel68);
            this.bntphongban.Controls.Add(this.panel72);
            this.bntphongban.Controls.Add(this.panel73);
            this.bntphongban.Controls.Add(this.panel74);
            this.bntphongban.Controls.Add(this.panel77);
            this.bntphongban.Controls.Add(this.panel79);
            this.bntphongban.Controls.Add(this.menuStrip2);
            this.bntphongban.Location = new System.Drawing.Point(4, 22);
            this.bntphongban.Name = "bntphongban";
            this.bntphongban.Padding = new System.Windows.Forms.Padding(3);
            this.bntphongban.Size = new System.Drawing.Size(745, 433);
            this.bntphongban.TabIndex = 5;
            this.bntphongban.Text = "Phòng Ban";
            this.bntphongban.UseVisualStyleBackColor = true;
            this.bntphongban.Click += new System.EventHandler(this.bntphongban_Click);
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "Phòng Giám Đốc",
            "Phòng Thị Trường",
            "Phòng Tổ Chức-Hành Chính",
            "Phòng Kinh doanh Đa Ngành",
            "Phòng Tài chính-Kế Toán",
            "Phòng Kinh Doanh"});
            this.comboBox2.Location = new System.Drawing.Point(447, 80);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(185, 21);
            this.comboBox2.TabIndex = 31;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // panel68
            // 
            this.panel68.Controls.Add(this.txtsdtPb);
            this.panel68.Controls.Add(this.label31);
            this.panel68.Location = new System.Drawing.Point(447, 199);
            this.panel68.Name = "panel68";
            this.panel68.Size = new System.Drawing.Size(291, 40);
            this.panel68.TabIndex = 30;
            // 
            // txtsdtPb
            // 
            this.txtsdtPb.Location = new System.Drawing.Point(159, 13);
            this.txtsdtPb.Name = "txtsdtPb";
            this.txtsdtPb.Size = new System.Drawing.Size(124, 20);
            this.txtsdtPb.TabIndex = 3;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(27, 16);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(131, 13);
            this.label31.TabIndex = 1;
            this.label31.Text = "Số Điện Thoại Phòng Ban";
            // 
            // panel72
            // 
            this.panel72.Controls.Add(this.label35);
            this.panel72.Controls.Add(this.txttenPb);
            this.panel72.Location = new System.Drawing.Point(447, 153);
            this.panel72.Name = "panel72";
            this.panel72.Size = new System.Drawing.Size(266, 40);
            this.panel72.TabIndex = 24;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(27, 16);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(82, 13);
            this.label35.TabIndex = 1;
            this.label35.Text = "Tên Phòng Ban";
            // 
            // txttenPb
            // 
            this.txttenPb.Location = new System.Drawing.Point(119, 12);
            this.txttenPb.Name = "txttenPb";
            this.txttenPb.Size = new System.Drawing.Size(131, 20);
            this.txttenPb.TabIndex = 2;
            // 
            // panel73
            // 
            this.panel73.Controls.Add(this.txtMaPB);
            this.panel73.Controls.Add(this.label36);
            this.panel73.Location = new System.Drawing.Point(447, 107);
            this.panel73.Name = "panel73";
            this.panel73.Size = new System.Drawing.Size(291, 40);
            this.panel73.TabIndex = 23;
            // 
            // txtMaPB
            // 
            this.txtMaPB.Location = new System.Drawing.Point(111, 9);
            this.txtMaPB.Name = "txtMaPB";
            this.txtMaPB.Size = new System.Drawing.Size(98, 20);
            this.txtMaPB.TabIndex = 3;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(27, 16);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(78, 13);
            this.label36.TabIndex = 1;
            this.label36.Text = "Mã Phòng Ban";
            // 
            // panel74
            // 
            this.panel74.Controls.Add(this.dtgvDepartment);
            this.panel74.Controls.Add(this.panel75);
            this.panel74.Controls.Add(this.panel76);
            this.panel74.Location = new System.Drawing.Point(6, 80);
            this.panel74.Name = "panel74";
            this.panel74.Size = new System.Drawing.Size(435, 340);
            this.panel74.TabIndex = 22;
            // 
            // dtgvDepartment
            // 
            this.dtgvDepartment.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvDepartment.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dtgvDepartment.Location = new System.Drawing.Point(0, 7);
            this.dtgvDepartment.Name = "dtgvDepartment";
            this.dtgvDepartment.Size = new System.Drawing.Size(435, 333);
            this.dtgvDepartment.TabIndex = 7;
            this.dtgvDepartment.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvDepartment_CellContentClick);
            this.dtgvDepartment.Click += new System.EventHandler(this.dtgvDepartment_Click);
            // 
            // panel75
            // 
            this.panel75.Location = new System.Drawing.Point(461, 0);
            this.panel75.Name = "panel75";
            this.panel75.Size = new System.Drawing.Size(281, 67);
            this.panel75.TabIndex = 5;
            // 
            // panel76
            // 
            this.panel76.Controls.Add(this.label37);
            this.panel76.Controls.Add(this.textBox33);
            this.panel76.Location = new System.Drawing.Point(437, 145);
            this.panel76.Name = "panel76";
            this.panel76.Size = new System.Drawing.Size(288, 40);
            this.panel76.TabIndex = 10;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(27, 16);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(67, 13);
            this.label37.TabIndex = 1;
            this.label37.Text = "Mã chức vụ:";
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(112, 13);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(173, 20);
            this.textBox33.TabIndex = 2;
            // 
            // panel77
            // 
            this.panel77.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel77.Controls.Add(this.txtcantim);
            this.panel77.Controls.Add(this.button20);
            this.panel77.Controls.Add(this.panel78);
            this.panel77.Location = new System.Drawing.Point(448, 16);
            this.panel77.Name = "panel77";
            this.panel77.Size = new System.Drawing.Size(296, 58);
            this.panel77.TabIndex = 21;
            // 
            // txtcantim
            // 
            this.txtcantim.Location = new System.Drawing.Point(19, 19);
            this.txtcantim.Name = "txtcantim";
            this.txtcantim.Size = new System.Drawing.Size(177, 20);
            this.txtcantim.TabIndex = 13;
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button20.Location = new System.Drawing.Point(202, 3);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(87, 51);
            this.button20.TabIndex = 12;
            this.button20.Text = "TÌM KIẾM";
            this.button20.UseVisualStyleBackColor = false;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // panel78
            // 
            this.panel78.Location = new System.Drawing.Point(461, 0);
            this.panel78.Name = "panel78";
            this.panel78.Size = new System.Drawing.Size(281, 67);
            this.panel78.TabIndex = 5;
            // 
            // panel79
            // 
            this.panel79.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel79.Controls.Add(this.button21);
            this.panel79.Controls.Add(this.btndelete);
            this.panel79.Controls.Add(this.button23);
            this.panel79.Controls.Add(this.btnthem);
            this.panel79.Controls.Add(this.panel80);
            this.panel79.Location = new System.Drawing.Point(0, 16);
            this.panel79.Name = "panel79";
            this.panel79.Size = new System.Drawing.Size(434, 58);
            this.panel79.TabIndex = 20;
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button21.Location = new System.Drawing.Point(344, 3);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(87, 51);
            this.button21.TabIndex = 11;
            this.button21.Text = "XEM";
            this.button21.UseVisualStyleBackColor = false;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // btndelete
            // 
            this.btndelete.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btndelete.Location = new System.Drawing.Point(117, 3);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(87, 51);
            this.btndelete.TabIndex = 10;
            this.btndelete.Text = "XÓA ";
            this.btndelete.UseVisualStyleBackColor = false;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click);
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button23.Location = new System.Drawing.Point(230, 3);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(87, 51);
            this.button23.TabIndex = 9;
            this.button23.Text = "SỬA";
            this.button23.UseVisualStyleBackColor = false;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // btnthem
            // 
            this.btnthem.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnthem.Location = new System.Drawing.Point(3, 3);
            this.btnthem.Name = "btnthem";
            this.btnthem.Size = new System.Drawing.Size(87, 51);
            this.btnthem.TabIndex = 8;
            this.btnthem.Text = "THÊM";
            this.btnthem.UseVisualStyleBackColor = false;
            this.btnthem.Click += new System.EventHandler(this.button24_Click);
            // 
            // panel80
            // 
            this.panel80.Location = new System.Drawing.Point(461, 0);
            this.panel80.Name = "panel80";
            this.panel80.Size = new System.Drawing.Size(281, 67);
            this.panel80.TabIndex = 5;
            // 
            // menuStrip2
            // 
            this.menuStrip2.Location = new System.Drawing.Point(3, 3);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(739, 24);
            this.menuStrip2.TabIndex = 29;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // btnbangluong
            // 
            this.btnbangluong.Controls.Add(this.panel91);
            this.btnbangluong.Controls.Add(this.panel90);
            this.btnbangluong.Controls.Add(this.panel89);
            this.btnbangluong.Controls.Add(this.panel88);
            this.btnbangluong.Controls.Add(this.panel92);
            this.btnbangluong.Controls.Add(this.panel69);
            this.btnbangluong.Controls.Add(this.panel70);
            this.btnbangluong.Controls.Add(this.panel71);
            this.btnbangluong.Controls.Add(this.panel81);
            this.btnbangluong.Controls.Add(this.panel84);
            this.btnbangluong.Controls.Add(this.panel86);
            this.btnbangluong.Location = new System.Drawing.Point(4, 22);
            this.btnbangluong.Name = "btnbangluong";
            this.btnbangluong.Padding = new System.Windows.Forms.Padding(3);
            this.btnbangluong.Size = new System.Drawing.Size(745, 433);
            this.btnbangluong.TabIndex = 6;
            this.btnbangluong.Text = "Bảng Lương";
            this.btnbangluong.UseVisualStyleBackColor = true;
            this.btnbangluong.Click += new System.EventHandler(this.btnbangluong_Click);
            // 
            // panel91
            // 
            this.panel91.Controls.Add(this.label41);
            this.panel91.Controls.Add(this.txtthuclinh);
            this.panel91.Location = new System.Drawing.Point(449, 398);
            this.panel91.Name = "panel91";
            this.panel91.Size = new System.Drawing.Size(248, 40);
            this.panel91.TabIndex = 35;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(27, 16);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(58, 13);
            this.label41.TabIndex = 1;
            this.label41.Text = "Thực Lĩnh";
            // 
            // txtthuclinh
            // 
            this.txtthuclinh.Location = new System.Drawing.Point(119, 13);
            this.txtthuclinh.Name = "txtthuclinh";
            this.txtthuclinh.Size = new System.Drawing.Size(101, 20);
            this.txtthuclinh.TabIndex = 2;
            // 
            // panel90
            // 
            this.panel90.Controls.Add(this.label40);
            this.panel90.Controls.Add(this.txtluong);
            this.panel90.Location = new System.Drawing.Point(448, 352);
            this.panel90.Name = "panel90";
            this.panel90.Size = new System.Drawing.Size(248, 40);
            this.panel90.TabIndex = 41;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(27, 16);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(37, 13);
            this.label40.TabIndex = 1;
            this.label40.Text = "Lương";
            // 
            // txtluong
            // 
            this.txtluong.Location = new System.Drawing.Point(119, 13);
            this.txtluong.Name = "txtluong";
            this.txtluong.Size = new System.Drawing.Size(101, 20);
            this.txtluong.TabIndex = 2;
            // 
            // panel89
            // 
            this.panel89.Controls.Add(this.label39);
            this.panel89.Controls.Add(this.txttenv);
            this.panel89.Location = new System.Drawing.Point(448, 122);
            this.panel89.Name = "panel89";
            this.panel89.Size = new System.Drawing.Size(248, 40);
            this.panel89.TabIndex = 35;
            this.panel89.Paint += new System.Windows.Forms.PaintEventHandler(this.panel89_Paint);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(27, 16);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(44, 13);
            this.label39.TabIndex = 1;
            this.label39.Text = "Tên NV";
            // 
            // txttenv
            // 
            this.txttenv.Location = new System.Drawing.Point(119, 13);
            this.txttenv.Name = "txttenv";
            this.txttenv.Size = new System.Drawing.Size(101, 20);
            this.txttenv.TabIndex = 2;
            // 
            // panel88
            // 
            this.panel88.Controls.Add(this.label28);
            this.panel88.Controls.Add(this.txtmanv);
            this.panel88.Location = new System.Drawing.Point(448, 76);
            this.panel88.Name = "panel88";
            this.panel88.Size = new System.Drawing.Size(280, 40);
            this.panel88.TabIndex = 40;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(27, 16);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(40, 13);
            this.label28.TabIndex = 1;
            this.label28.Text = "Mã NV";
            // 
            // txtmanv
            // 
            this.txtmanv.Location = new System.Drawing.Point(119, 13);
            this.txtmanv.Name = "txtmanv";
            this.txtmanv.Size = new System.Drawing.Size(101, 20);
            this.txtmanv.TabIndex = 2;
            // 
            // panel92
            // 
            this.panel92.Controls.Add(this.txthesophucap);
            this.panel92.Controls.Add(this.label43);
            this.panel92.Location = new System.Drawing.Point(448, 306);
            this.panel92.Name = "panel92";
            this.panel92.Size = new System.Drawing.Size(248, 40);
            this.panel92.TabIndex = 39;
            // 
            // txthesophucap
            // 
            this.txthesophucap.Location = new System.Drawing.Point(119, 13);
            this.txthesophucap.Name = "txthesophucap";
            this.txthesophucap.Size = new System.Drawing.Size(101, 20);
            this.txthesophucap.TabIndex = 3;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(27, 16);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(81, 13);
            this.label43.TabIndex = 1;
            this.label43.Text = "Hệ Số Phụ Cấp";
            // 
            // panel69
            // 
            this.panel69.Controls.Add(this.txthesoluong);
            this.panel69.Controls.Add(this.label32);
            this.panel69.Location = new System.Drawing.Point(448, 260);
            this.panel69.Name = "panel69";
            this.panel69.Size = new System.Drawing.Size(248, 40);
            this.panel69.TabIndex = 36;
            // 
            // txthesoluong
            // 
            this.txthesoluong.Location = new System.Drawing.Point(119, 9);
            this.txthesoluong.Name = "txthesoluong";
            this.txthesoluong.Size = new System.Drawing.Size(101, 20);
            this.txthesoluong.TabIndex = 3;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(27, 16);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(70, 13);
            this.label32.TabIndex = 1;
            this.label32.Text = "Hệ Số Lương";
            // 
            // panel70
            // 
            this.panel70.Controls.Add(this.txtluongcoban);
            this.panel70.Controls.Add(this.label33);
            this.panel70.Location = new System.Drawing.Point(448, 214);
            this.panel70.Name = "panel70";
            this.panel70.Size = new System.Drawing.Size(248, 40);
            this.panel70.TabIndex = 35;
            // 
            // txtluongcoban
            // 
            this.txtluongcoban.Location = new System.Drawing.Point(119, 13);
            this.txtluongcoban.Name = "txtluongcoban";
            this.txtluongcoban.Size = new System.Drawing.Size(101, 20);
            this.txtluongcoban.TabIndex = 3;
            this.txtluongcoban.TextChanged += new System.EventHandler(this.textBox35_TextChanged);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(27, 16);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(75, 13);
            this.label33.TabIndex = 1;
            this.label33.Text = "Lương Cơ Bản";
            // 
            // panel71
            // 
            this.panel71.Controls.Add(this.label34);
            this.panel71.Controls.Add(this.txtbacluong);
            this.panel71.Location = new System.Drawing.Point(448, 168);
            this.panel71.Name = "panel71";
            this.panel71.Size = new System.Drawing.Size(248, 40);
            this.panel71.TabIndex = 34;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(27, 16);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(59, 13);
            this.label34.TabIndex = 1;
            this.label34.Text = "Bậc Lương";
            // 
            // txtbacluong
            // 
            this.txtbacluong.Location = new System.Drawing.Point(119, 13);
            this.txtbacluong.Name = "txtbacluong";
            this.txtbacluong.Size = new System.Drawing.Size(101, 20);
            this.txtbacluong.TabIndex = 2;
            this.txtbacluong.TextChanged += new System.EventHandler(this.txtbacluong_TextChanged);
            // 
            // panel81
            // 
            this.panel81.Controls.Add(this.dtgvSalary);
            this.panel81.Controls.Add(this.panel82);
            this.panel81.Controls.Add(this.panel83);
            this.panel81.Location = new System.Drawing.Point(6, 78);
            this.panel81.Name = "panel81";
            this.panel81.Size = new System.Drawing.Size(435, 340);
            this.panel81.TabIndex = 33;
            // 
            // dtgvSalary
            // 
            this.dtgvSalary.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvSalary.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dtgvSalary.Location = new System.Drawing.Point(0, 7);
            this.dtgvSalary.Name = "dtgvSalary";
            this.dtgvSalary.Size = new System.Drawing.Size(435, 333);
            this.dtgvSalary.TabIndex = 7;
            this.dtgvSalary.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvSalary_CellContentClick);
            this.dtgvSalary.Click += new System.EventHandler(this.dtgvSalary_Click);
            // 
            // panel82
            // 
            this.panel82.Location = new System.Drawing.Point(461, 0);
            this.panel82.Name = "panel82";
            this.panel82.Size = new System.Drawing.Size(281, 67);
            this.panel82.TabIndex = 5;
            // 
            // panel83
            // 
            this.panel83.Controls.Add(this.label38);
            this.panel83.Controls.Add(this.textBox38);
            this.panel83.Location = new System.Drawing.Point(437, 145);
            this.panel83.Name = "panel83";
            this.panel83.Size = new System.Drawing.Size(288, 40);
            this.panel83.TabIndex = 10;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(27, 16);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(67, 13);
            this.label38.TabIndex = 1;
            this.label38.Text = "Mã chức vụ:";
            // 
            // textBox38
            // 
            this.textBox38.Location = new System.Drawing.Point(112, 13);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(173, 20);
            this.textBox38.TabIndex = 2;
            // 
            // panel84
            // 
            this.panel84.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel84.Controls.Add(this.txtmacantim);
            this.panel84.Controls.Add(this.button25);
            this.panel84.Controls.Add(this.panel85);
            this.panel84.Location = new System.Drawing.Point(448, 14);
            this.panel84.Name = "panel84";
            this.panel84.Size = new System.Drawing.Size(328, 58);
            this.panel84.TabIndex = 32;
            // 
            // txtmacantim
            // 
            this.txtmacantim.Location = new System.Drawing.Point(19, 19);
            this.txtmacantim.Name = "txtmacantim";
            this.txtmacantim.Size = new System.Drawing.Size(177, 20);
            this.txtmacantim.TabIndex = 13;
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button25.Location = new System.Drawing.Point(202, 3);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(87, 51);
            this.button25.TabIndex = 12;
            this.button25.Text = "TÌM KIẾM";
            this.button25.UseVisualStyleBackColor = false;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // panel85
            // 
            this.panel85.Location = new System.Drawing.Point(461, 0);
            this.panel85.Name = "panel85";
            this.panel85.Size = new System.Drawing.Size(281, 67);
            this.panel85.TabIndex = 5;
            // 
            // panel86
            // 
            this.panel86.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel86.Controls.Add(this.button26);
            this.panel86.Controls.Add(this.btnxoa);
            this.panel86.Controls.Add(this.btnsua);
            this.panel86.Controls.Add(this.bntthem);
            this.panel86.Controls.Add(this.panel87);
            this.panel86.Location = new System.Drawing.Point(0, 14);
            this.panel86.Name = "panel86";
            this.panel86.Size = new System.Drawing.Size(434, 58);
            this.panel86.TabIndex = 31;
            // 
            // button26
            // 
            this.button26.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button26.Location = new System.Drawing.Point(344, 3);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(87, 51);
            this.button26.TabIndex = 11;
            this.button26.Text = "XEM";
            this.button26.UseVisualStyleBackColor = false;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // btnxoa
            // 
            this.btnxoa.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnxoa.Location = new System.Drawing.Point(117, 3);
            this.btnxoa.Name = "btnxoa";
            this.btnxoa.Size = new System.Drawing.Size(87, 51);
            this.btnxoa.TabIndex = 10;
            this.btnxoa.Text = "XÓA ";
            this.btnxoa.UseVisualStyleBackColor = false;
            this.btnxoa.Click += new System.EventHandler(this.button27_Click);
            // 
            // btnsua
            // 
            this.btnsua.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnsua.Location = new System.Drawing.Point(230, 3);
            this.btnsua.Name = "btnsua";
            this.btnsua.Size = new System.Drawing.Size(87, 51);
            this.btnsua.TabIndex = 9;
            this.btnsua.Text = "SỬA";
            this.btnsua.UseVisualStyleBackColor = false;
            this.btnsua.Click += new System.EventHandler(this.button28_Click);
            // 
            // bntthem
            // 
            this.bntthem.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.bntthem.Location = new System.Drawing.Point(3, 3);
            this.bntthem.Name = "bntthem";
            this.bntthem.Size = new System.Drawing.Size(87, 51);
            this.bntthem.TabIndex = 8;
            this.bntthem.Text = "THÊM";
            this.bntthem.UseVisualStyleBackColor = false;
            this.bntthem.Click += new System.EventHandler(this.button29_Click);
            // 
            // panel87
            // 
            this.panel87.Location = new System.Drawing.Point(461, 0);
            this.panel87.Name = "panel87";
            this.panel87.Size = new System.Drawing.Size(281, 67);
            this.panel87.TabIndex = 5;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // fAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(902, 491);
            this.Controls.Add(this.btnphongban);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "fAdmin";
            this.Text = "fAdmin";
            this.Load += new System.EventHandler(this.fAdmin_Load);
            this.btnphongban.ResumeLayout(false);
            this.tabStaffInfor.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvStaff)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.panel30.ResumeLayout(false);
            this.panel31.ResumeLayout(false);
            this.panel31.PerformLayout();
            this.panel32.ResumeLayout(false);
            this.panel32.PerformLayout();
            this.panel34.ResumeLayout(false);
            this.panel34.PerformLayout();
            this.panel35.ResumeLayout(false);
            this.panel35.PerformLayout();
            this.panel36.ResumeLayout(false);
            this.panel36.PerformLayout();
            this.panel27.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvAssignment)).EndInit();
            this.panel12.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panel22.ResumeLayout(false);
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            this.panel26.ResumeLayout(false);
            this.panel26.PerformLayout();
            this.panel28.ResumeLayout(false);
            this.panel28.PerformLayout();
            this.panel20.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvPosition)).EndInit();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.panel54.ResumeLayout(false);
            this.panel54.PerformLayout();
            this.panel53.ResumeLayout(false);
            this.panel53.PerformLayout();
            this.panel52.ResumeLayout(false);
            this.panel52.PerformLayout();
            this.panel51.ResumeLayout(false);
            this.panel51.PerformLayout();
            this.panel50.ResumeLayout(false);
            this.panel50.PerformLayout();
            this.panel43.ResumeLayout(false);
            this.panel49.ResumeLayout(false);
            this.panel49.PerformLayout();
            this.panel45.ResumeLayout(false);
            this.panel45.PerformLayout();
            this.panel47.ResumeLayout(false);
            this.panel47.PerformLayout();
            this.panel48.ResumeLayout(false);
            this.panel48.PerformLayout();
            this.panel41.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvLevel)).EndInit();
            this.panel44.ResumeLayout(false);
            this.panel44.PerformLayout();
            this.panel37.ResumeLayout(false);
            this.panel37.PerformLayout();
            this.panel38.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.panel65.ResumeLayout(false);
            this.panel67.ResumeLayout(false);
            this.panel67.PerformLayout();
            this.panel66.ResumeLayout(false);
            this.panel66.PerformLayout();
            this.panel64.ResumeLayout(false);
            this.panel64.PerformLayout();
            this.panel62.ResumeLayout(false);
            this.panel62.PerformLayout();
            this.panel63.ResumeLayout(false);
            this.panel63.PerformLayout();
            this.panel59.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtdvContract)).EndInit();
            this.panel61.ResumeLayout(false);
            this.panel61.PerformLayout();
            this.panel57.ResumeLayout(false);
            this.panel57.PerformLayout();
            this.panel55.ResumeLayout(false);
            this.bntphongban.ResumeLayout(false);
            this.bntphongban.PerformLayout();
            this.panel68.ResumeLayout(false);
            this.panel68.PerformLayout();
            this.panel72.ResumeLayout(false);
            this.panel72.PerformLayout();
            this.panel73.ResumeLayout(false);
            this.panel73.PerformLayout();
            this.panel74.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvDepartment)).EndInit();
            this.panel76.ResumeLayout(false);
            this.panel76.PerformLayout();
            this.panel77.ResumeLayout(false);
            this.panel77.PerformLayout();
            this.panel79.ResumeLayout(false);
            this.btnbangluong.ResumeLayout(false);
            this.panel91.ResumeLayout(false);
            this.panel91.PerformLayout();
            this.panel90.ResumeLayout(false);
            this.panel90.PerformLayout();
            this.panel89.ResumeLayout(false);
            this.panel89.PerformLayout();
            this.panel88.ResumeLayout(false);
            this.panel88.PerformLayout();
            this.panel92.ResumeLayout(false);
            this.panel92.PerformLayout();
            this.panel69.ResumeLayout(false);
            this.panel69.PerformLayout();
            this.panel70.ResumeLayout(false);
            this.panel70.PerformLayout();
            this.panel71.ResumeLayout(false);
            this.panel71.PerformLayout();
            this.panel81.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvSalary)).EndInit();
            this.panel83.ResumeLayout(false);
            this.panel83.PerformLayout();
            this.panel84.ResumeLayout(false);
            this.panel84.PerformLayout();
            this.panel86.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl btnphongban;
        private System.Windows.Forms.TabPage tabStaffInfor;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox txbNameID;
        private System.Windows.Forms.Label lbPassId;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.DataGridView dtgvStaff;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button btnAddStaff;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button btnShowStaff;
        private System.Windows.Forms.Button btnDeleteStaff;
        private System.Windows.Forms.Button btnEditStaff;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.TextBox txbNameStaff;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.DataGridView dtgvAssignment;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Button btnAssignment;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.DataGridView dtgvPosition;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Panel panel36;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.Panel panel43;
        private System.Windows.Forms.Panel panel49;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.Panel panel45;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.Panel panel46;
        private System.Windows.Forms.Panel panel47;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Panel panel48;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.Panel panel41;
        private System.Windows.Forms.DataGridView dtgvLevel;
        private System.Windows.Forms.Panel panel42;
        private System.Windows.Forms.Panel panel37;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Panel panel40;
        private System.Windows.Forms.Panel panel38;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Panel panel39;
        private System.Windows.Forms.Panel panel54;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.Panel panel53;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.Panel panel52;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.Panel panel51;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.Panel panel50;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.Panel panel44;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Panel panel67;
        private System.Windows.Forms.DateTimePicker dateTimePicker4;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Panel panel66;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Panel panel64;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.Panel panel62;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.Panel panel63;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.Panel panel59;
        private System.Windows.Forms.DataGridView dtdvContract;
        private System.Windows.Forms.Panel panel60;
        private System.Windows.Forms.Panel panel61;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.Panel panel57;
        private System.Windows.Forms.Panel panel58;
        private System.Windows.Forms.Panel panel55;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Panel panel56;
        private System.Windows.Forms.DateTimePicker dateTimePicker5;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.TabPage bntphongban;
        private System.Windows.Forms.Panel panel72;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Panel panel73;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Panel panel74;
        private System.Windows.Forms.DataGridView dtgvDepartment;
        private System.Windows.Forms.Panel panel75;
        private System.Windows.Forms.Panel panel76;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.Panel panel77;
        private System.Windows.Forms.TextBox txtcantim;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Panel panel78;
        private System.Windows.Forms.Panel panel79;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button btndelete;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button btnthem;
        private System.Windows.Forms.Panel panel80;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.TabPage btnbangluong;
        private System.Windows.Forms.TextBox txttenPb;
        private System.Windows.Forms.Panel panel68;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Panel panel92;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Panel panel69;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Panel panel70;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Panel panel71;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox txtbacluong;
        private System.Windows.Forms.Panel panel81;
        private System.Windows.Forms.DataGridView dtgvSalary;
        private System.Windows.Forms.Panel panel82;
        private System.Windows.Forms.Panel panel83;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.Panel panel84;
        private System.Windows.Forms.TextBox txtmacantim;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Panel panel85;
        private System.Windows.Forms.Panel panel86;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button btnxoa;
        private System.Windows.Forms.Button btnsua;
        private System.Windows.Forms.Button bntthem;
        private System.Windows.Forms.Panel panel87;
        private System.Windows.Forms.Panel panel65;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Panel panel93;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.TextBox txtsdtPb;
        private System.Windows.Forms.TextBox txthesophucap;
        private System.Windows.Forms.TextBox txthesoluong;
        private System.Windows.Forms.TextBox txtluongcoban;
        private System.Windows.Forms.TextBox txtMaPB;
        private System.Windows.Forms.Panel panel89;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox txttenv;
        private System.Windows.Forms.Panel panel88;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtmanv;
        private System.Windows.Forms.Panel panel91;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox txtthuclinh;
        private System.Windows.Forms.Panel panel90;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox txtluong;
        private System.Windows.Forms.ComboBox comboBox2;
    }
}