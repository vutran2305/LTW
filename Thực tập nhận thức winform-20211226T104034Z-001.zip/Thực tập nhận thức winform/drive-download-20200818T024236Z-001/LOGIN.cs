﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace QUANLYNHANSU
{
    public partial class fLOGIN : Form
    {
        public fLOGIN()
        {
            InitializeComponent();
        }

        

        private void btnLogin_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-BDK2JHV\SQLEXPRESS;Initial Catalog=quanlinhanvien;Integrated Security=True");
     try
     {
         conn.Open();
         string tk =txtusername.Text;
         string mk = txtpassword.Text;
         string sql = "select * from dangnhap where Tendangnhap='"+tk+"'and matkhau='"+mk+"' ";
         SqlCommand cmd = new SqlCommand (sql,conn);
         SqlDataReader dta=cmd.ExecuteReader();
         if (dta.Read()==true)
         {
             MessageBox.Show("Đăng nhập thành công");
         }
         else 
         {
             MessageBox.Show("Đăng nhập thất bại");
         }
     }
            catch
     {
                MessageBox.Show("Lỗi kết nối ");
            }
     fTABLEMANAGER fm = new fTABLEMANAGER();
     fm.Show();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void fLOGIN_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Bạn có muốn thoát chương trình","Thông Báo", MessageBoxButtons.OKCancel) != System.Windows.Forms.DialogResult.OK)
            {
                e.Cancel = true;
            }
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void fLOGIN_Load(object sender, EventArgs e)
        {
            txtusername.Focus();
            txtpassword.Focus();
        }
        
       
    }
}
