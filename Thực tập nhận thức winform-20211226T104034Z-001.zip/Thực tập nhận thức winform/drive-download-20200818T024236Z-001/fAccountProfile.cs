﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace QUANLYNHANSU
{
    public partial class fAccountProfile : Form
    {
        public fAccountProfile()
        {
            InitializeComponent();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void fAccountProfile_Load(object sender, EventArgs e)
        {

        }
        private void ketnoi()
        {
            try
            {
                SqlConnection kn = new SqlConnection(@"Data Source=DESKTOP-BDK2JHV\SQLEXPRESS;Initial Catalog=quanlinhanvien;Integrated Security=True");
                kn.Open();
                string sql = " select * from dangnhap ";
                SqlCommand commandsql = new SqlCommand(sql, kn);
                SqlDataReader dr = commandsql.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(dr);
                
            }
            catch
            {
                MessageBox.Show("Lỗi kết nối ,vui lòng kiểm tra lại ");
            }
            finally
            {
                SqlConnection kn = new SqlConnection(@"Data Source=DESKTOP-BDK2JHV\SQLEXPRESS;Initial Catalog=quanlinhanvien;Integrated Security=True");
                kn.Close();
            }
        }
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            SqlConnection kn = new SqlConnection(@"Data Source=DESKTOP-BDK2JHV\SQLEXPRESS;Initial Catalog=quanlinhanvien;Integrated Security=True");
            kn.Open();

            string editt = "UPDATE dangnhap SET matkhau = @matkhau, Where Tendangnhap=@Tendangnhap";
            SqlCommand commandthem = new SqlCommand(editt, kn);
            commandthem.Parameters.AddWithValue("Tendangnhap", txttendangnhap.Text);
            commandthem.Parameters.AddWithValue("matkhau", txbEnterPass.Text);
          
            commandthem.ExecuteNonQuery();
            ketnoi();

        }

      

    }
}
