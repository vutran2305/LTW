﻿using QUANLYNHANSU.DAO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace QUANLYNHANSU
{
    public partial class fAdmin : Form
    {
        
        public fAdmin()
        {
            InitializeComponent();
            LoadAccountList();
          
        }
       
        private void ketnoi()
        {
            try
            {
                SqlConnection kn = new SqlConnection(@"Data Source=DESKTOP-BDK2JHV\SQLEXPRESS;Initial Catalog=quanlinhanvien;Integrated Security=True");
                kn.Open();
                string sql = " select * from luong ";
                SqlCommand commandsql = new SqlCommand(sql, kn);
                SqlDataReader dr = commandsql.ExecuteReader();
                DataTable dt = new DataTable();
               dt.Load(dr);
                dtgvSalary.DataSource = dt;
                
            }
            catch
            {
                MessageBox.Show("Lỗi kết nối ,vui lòng kiểm tra lại ");
            }
            finally
            {
                SqlConnection kn = new SqlConnection(@"Data Source=DESKTOP-BDK2JHV\SQLEXPRESS;Initial Catalog=quanlinhanvien;Integrated Security=True");
            }
        }
        void LoadAccountList()
        {

            string query = "Select * from nhanvien";
            string query1="Select * from phongban";
            string query2 = "Select * from phancongcongtac";
            string query3 = "Select * from chucvu";
            string query4 = "Select * from trinhdo";
            string query5 = "Select * from luong";
            string query6 = "Select * from hopdonglaodong";
            DataProvider provider = new DataProvider();

            dtgvStaff.DataSource = provider.ExecuteQuery(query);
            dtgvDepartment.DataSource = provider.ExecuteQuery(query1);
            dtgvAssignment.DataSource = provider.ExecuteQuery(query2);
            dtgvPosition.DataSource = provider.ExecuteQuery(query3);
            dtgvLevel.DataSource = provider.ExecuteQuery(query4);
            dtgvSalary.DataSource = provider.ExecuteQuery(query5);
            dtdvContract.DataSource = provider.ExecuteQuery(query6);
        }

        private void dtgvStaff_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel14_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox35_TextChanged(object sender, EventArgs e)
        {

        }

        private void dtgvAssignment_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dtgvDepartment_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dtgvPosition_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dtgvLevel_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dtgvSalary_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void dtdvContract_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnShowStaff_Click(object sender, EventArgs e)
        {

        }

        private void btnAddStaff_Click(object sender, EventArgs e)
        {

        }
        private void button24_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection qn = new SqlConnection(@"Data Source=DESKTOP-BDK2JHV\SQLEXPRESS;Initial Catalog=quanlinhanvien;Integrated Security=True");
                qn.Open();
                string set = "Insert into phongban Values('" + txttenPb + "','" + txtMaPB + "','" + txtsdtPb.Text
                    + "')";
                SqlCommand cmdset = new SqlCommand(set, qn);
                cmdset.ExecuteNonQuery();
                hienthi();
            }
            catch
            {
                MessageBox.Show("Lỗi,đã trùng trong bảng ");
            }
            finally
            {
                SqlConnection kn = new SqlConnection(@"Data Source=DESKTOP-BDK2JHV\SQLEXPRESS;Initial Catalog=quanlinhanvien;Integrated Security=True");
                kn.Close();
            }
        }
        int index;
        private void dtgvDepartment_Click(object sender, EventArgs e)
        {
        index = dtgvDepartment.CurrentRow.Index;
           
             txtMaPB.Text =dtgvDepartment.Rows[index].Cells[0].Value.ToString();
             txttenPb.Text =dtgvDepartment.Rows[index].Cells[1].Value.ToString();
             txtsdtPb.Text =dtgvDepartment.Rows[index].Cells[2].Value.ToString();


        }

        private void bntphongban_Click(object sender, EventArgs e)
        {

        }

        private void btnbangluong_Click(object sender, EventArgs e)
        {

        }

        private void dtgvSalary_Click(object sender, EventArgs e)
        {
            index = dtgvSalary.CurrentRow.Index;
            txtmanv.Text=dtgvSalary.Rows[index].Cells[0].Value.ToString();
            txttenv.Text = dtgvSalary.Rows[index].Cells[1].Value.ToString();
            txtbacluong.Text = dtgvSalary.Rows[index].Cells[2].Value.ToString();
            txtluongcoban.Text = dtgvSalary.Rows[index].Cells[3].Value.ToString();
            txthesoluong.Text = dtgvSalary.Rows[index].Cells[4].Value.ToString();
            txthesophucap.Text = dtgvSalary.Rows[index].Cells[5].Value.ToString();
            
          
        }
        string them;
        private void button29_Click(object sender, EventArgs e)
        {
            try
            {

            SqlConnection kn = new SqlConnection(@"Data Source=DESKTOP-BDK2JHV\SQLEXPRESS;Initial Catalog=quanlinhanvien;Integrated Security=True");
                kn.Open();
                them = "Insert into luong Values('" + txtbacluong.Text + "','" + txtluongcoban.Text + "','" + txthesoluong.Text
                    +"','"+ txthesophucap.Text +"')";
                SqlCommand commandthem = new SqlCommand(them,kn);
                commandthem.ExecuteNonQuery();
                ketnoi();
               
            }
            catch
            {
                MessageBox.Show("Lỗi,đã trùng trong bảng ");
            }
            finally
            {
                SqlConnection kn = new SqlConnection(@"Data Source=DESKTOP-BDK2JHV\SQLEXPRESS;Initial Catalog=quanlinhanvien;Integrated Security=True");
                kn.Close();
            }
        }

        private void button27_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection kn = new SqlConnection(@"Data Source=DESKTOP-BDK2JHV\SQLEXPRESS;Initial Catalog=quanlinhanvien;Integrated Security=True");
                kn.Open();
                string delete = "Delete from luong where BacLuong =@BacLuong";
                SqlCommand commandthem = new SqlCommand(delete, kn);
                commandthem.Parameters.AddWithValue("BacLuong", txtbacluong.Text);
                commandthem.Parameters.AddWithValue("LuongCB", txtluongcoban.Text);
                commandthem.Parameters.AddWithValue("HSLuong", txthesoluong.Text);
                commandthem.Parameters.AddWithValue("HeSoPhuCap", txthesophucap.Text);
                commandthem.ExecuteNonQuery();
                ketnoi();
            }
            catch
            {
                if(txtmanv.Text.Length==0 && txtluongcoban.Text.Length==0)
                MessageBox.Show("Lỗi,không xóa được ");
            }
            finally
            {
                SqlConnection kn = new SqlConnection(@"Data Source=DESKTOP-BDK2JHV\SQLEXPRESS;Initial Catalog=quanlinhanvien;Integrated Security=True");
                kn.Close();
            }
           
        }

        private void button28_Click(object sender, EventArgs e)
        {
            SqlConnection kn = new SqlConnection(@"Data Source=DESKTOP-BDK2JHV\SQLEXPRESS;Initial Catalog=quanlinhanvien;Integrated Security=True");
            kn.Open();

            string edit = "UPDATE luong SET MaNV=@MaNV,TenNV=@TenNV,LuongCB = @LuongCB,HSLuong=@HSLuong,HeSoPhuCap=@HeSoPhuCap,Luong=@Luong,ThucLinh=@ThucLinh Where BacLuong =@BacLuong";
            SqlCommand commandthem = new SqlCommand(edit, kn);
            commandthem.Parameters.AddWithValue("MaNV ", txtmanv.Text);
            commandthem.Parameters.AddWithValue("TenNV", txttenv.Text);
            commandthem.Parameters.AddWithValue("BacLuong", txtbacluong.Text);
            commandthem.Parameters.AddWithValue("LuongCB", txtluongcoban.Text);
            commandthem.Parameters.AddWithValue("HSLuong", txthesoluong.Text);
            commandthem.Parameters.AddWithValue("HeSoPhuCap", txthesophucap.Text);
            commandthem.Parameters.AddWithValue("Luong ", txtluong.Text);
            commandthem.Parameters.AddWithValue("ThucLinh", txtthuclinh.Text);
            commandthem.ExecuteNonQuery();
            ketnoi();
        }
      
        private void btnEditStaff_Click(object sender, EventArgs e)
        {
            SqlConnection kn = new SqlConnection(@"Data Source=DESKTOP-BDK2JHV\SQLEXPRESS;Initial Catalog=quanlinhanvien;Integrated Security=True");
            kn.Open();
            
            string edit = "UPDATE luong SET MaNV=@MaNV,TenNV=@TenNV,LuongCB = @LuongCB,HSLuong=@HSLuong,HeSoPhuCap=@HeSoPhuCap,Luong=@Luong,ThucLinh=@ThucLinh Where BacLuong =@BacLuong";
            SqlCommand commandthem = new SqlCommand(edit, kn);
            commandthem.Parameters.AddWithValue("MaNV ", txtmanv.Text);
            commandthem.Parameters.AddWithValue("TenNV", txttenv.Text);
            commandthem.Parameters.AddWithValue("BacLuong", txtbacluong.Text);
            commandthem.Parameters.AddWithValue("LuongCB", txtluongcoban.Text);
            commandthem.Parameters.AddWithValue("HSLuong", txthesoluong.Text);
            commandthem.Parameters.AddWithValue("HeSoPhuCap", txthesophucap.Text);
            commandthem.Parameters.AddWithValue("Luong ", txtluong.Text);
            commandthem.Parameters.AddWithValue("ThucLinh", txtthuclinh.Text);
            commandthem.ExecuteNonQuery();
            ketnoi();
        }

        private void button26_Click(object sender, EventArgs e)
        {
            LoadAccountList();
        }

        private void button25_Click(object sender, EventArgs e)
        {
            SqlConnection kn = new SqlConnection(@"Data Source=DESKTOP-BDK2JHV\SQLEXPRESS;Initial Catalog=quanlinhanvien;Integrated Security=True");
            kn.Open();
            string timkiem = "Select * From luong where HoTen=@HoTen ";
            
            SqlCommand commandthem = new SqlCommand(timkiem, kn);
            commandthem.Parameters.AddWithValue("MaNV", txtmanv.Text);
            commandthem.Parameters.AddWithValue("HoTen", txtmacantim.Text);
            commandthem.Parameters.AddWithValue("BacLuong", txtbacluong.Text);
            commandthem.Parameters.AddWithValue("LuongCB",txtluongcoban.Text);
            commandthem.Parameters.AddWithValue("HSLuong", txthesoluong.Text);
            commandthem.Parameters.AddWithValue("HeSoPhuCap", txthesophucap.Text);
            commandthem.Parameters.AddWithValue("Luong ", txtluong.Text);
            commandthem.Parameters.AddWithValue("ThucLinh", txtthuclinh.Text);

            SqlDataReader dr = commandthem.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dtgvSalary.DataSource = dt;

            
        }
        private void hienthi()
        {
           
                SqlConnection qn = new SqlConnection(@"Data Source=DESKTOP-BDK2JHV\SQLEXPRESS;Initial Catalog=quanlinhanvien;Integrated Security=True");
                qn.Open();
                string dtq = " select * from phongban ";
                SqlCommand cmd = new SqlCommand(dtq, qn);
                SqlDataReader rd = cmd.ExecuteReader();
                DataTable dg = new DataTable();
                dg.Load(rd);
                dtgvDepartment.DataSource = dg;
           
        }

        private void button23_Click(object sender, EventArgs e)
        {
            SqlConnection qn = new SqlConnection(@"Data Source=DESKTOP-BDK2JHV\SQLEXPRESS;Initial Catalog=quanlinhanvien;Integrated Security=True");
            qn.Open();

            string sua = "UPDATE phongban SET TenPB=@TenPB,SDTPB=@SDTPB Where MaPB=@MaPB";
            SqlCommand commandthem = new SqlCommand(sua, qn);
            commandthem.Parameters.AddWithValue("MaPB", txtMaPB.Text);
            commandthem.Parameters.AddWithValue("TenPB", txttenPb.Text);
            commandthem.Parameters.AddWithValue("SDTPB", txtsdtPb.Text);
            commandthem.ExecuteNonQuery();
            hienthi();
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
     
            {
                SqlConnection kn = new SqlConnection(@"Data Source=DESKTOP-BDK2JHV\SQLEXPRESS;Initial Catalog=quanlinhanvien;Integrated Security=True");
                kn.Open();
                string xoa = "Delete from phongban where MaPB =@MaPB";
                SqlCommand commandthem = new SqlCommand(xoa, kn);
                commandthem.Parameters.AddWithValue("MaPB", txtMaPB.Text);
                commandthem.Parameters.AddWithValue("TenPB", txttenPb.Text);
                commandthem.Parameters.AddWithValue("SDTPB", txtsdtPb.Text);
                commandthem.ExecuteNonQuery();
                hienthi();
            }
            
        }

        private void button20_Click(object sender, EventArgs e)
        {
            SqlConnection kn = new SqlConnection(@"Data Source=DESKTOP-BDK2JHV\SQLEXPRESS;Initial Catalog=quanlinhanvien;Integrated Security=True");
            kn.Open();
            string tim = "Select * From phongban where MaPB=@MaPB";
            SqlCommand commandthem = new SqlCommand(tim, kn);
            commandthem.Parameters.AddWithValue("MaPB", txtcantim.Text);
            commandthem.Parameters.AddWithValue("TenPB", txttenPb.Text);
            commandthem.Parameters.AddWithValue("SDTPB", txtsdtPb.Text);
            SqlDataReader dr = commandthem.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dtgvDepartment.DataSource = dt;
        }

        private void fAdmin_Load(object sender, EventArgs e)
        {

        }

        private void panel89_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button21_Click(object sender, EventArgs e)
        {
            LoadAccountList();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            


        }

        private void txtbacluong_TextChanged(object sender, EventArgs e)
        {

        }
      
         
    }
}
